# live2d
网页嵌入看板娘

具体使用教程在这里: https://www.baikesec.com/phpstudy/others/64.html
